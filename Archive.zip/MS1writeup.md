# Milestone 1 Write-up

## Symbol Table Design
I implemented a hierarchical symbol table structure using a SymbolTable class with parent pointers like we discussed in class. The global scope contains functions and global variables, while each function creates a local scope for parameters and local variables. The lookup method searches up the scope chain, enabling behavior where locals can hide globals.

## Namespace Separation
Like the Mini specification states I stored structs in a separate struct_table dictionary, seperate from the variable/function namespace. This allows variables and struct types to share names.

## Type Checking
I created a TypeInfo wrapper class to uniformly compare types. Type checking occurs at assignments, operators, function calls, and return statements. Special handling for null allows it to be assigned to any struct type. Binary operators report a single error per operation to avoid duplicates.

## Forward References
Struct declarations use a two-pass approach. First, all struct names are registered to enable forward references and self-referential types, then fields are validated in a second pass.

## Return Statement Validation
For non-void functions, I check if the last statement is a return or if/else with returns in both branches. The checker recursively validates nested blocks. Empty returns in non-void functions are caught as errors.

## Error Reporting
Errors are collected during traversal and printed at the end in the format `ERROR. <message> #<linenum>`, followed by `ERRORS FOUND <count>`.

## Key Implementation Decisions
- Single AST traversal for efficiency
- Separate info classes (`FunctionInfo`, `VariableInfo`, `StructInfo`) store declaration metadata
- null is represented as a special struct type for uniform handling
- Redeclaration checking at all scoping levels (global, function parameters, locals, struct fields)
- Program validates presence of main with correct signature (no args, returns int)